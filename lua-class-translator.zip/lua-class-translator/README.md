# Lua 类名 / 字段名批量翻译器

把游戏逆向导出的 Lua 表（形如 `['ADGBuffSkillDurationEffectTick'] = { -- table(xxx) }`）里的
**类名**和 **`name` 字段名**批量翻成中文：**原名保留，后面追加 `\n` 和中文**。
类型前缀（`int32` / `bool` / `StringId` / `TArray<...>`）和偏移数字（`[104]`）原样不动。

```lua
['ADGBuffSkillDurationEffectTick\nADG增益技能持续时间效果每帧'] = { -- table(2f0130f)
    [104] = { -- table(...)
        ['flags'] = 'StringId',
        ['name'] = 'StringId  actionName\n动作名称',
```

`\n` 是 Lua 字符串里的换行转义，运行时打断成两行：英文原名 + 中文翻译，两者都在。

> 为什么不直接把文件丢给翻译网站：这类名字是 PascalCase 标识符，整串丢进去会被当生词，
> 结果基本不可读。本工具的做法是「驼峰拆词 → 游戏术语词典逐词翻译 → 中文拼接」，
> 再用内置的 Lua 语法校验器证明输出的表仍然合法。

## 用法一：拖文件（推荐，不用命令行）

把 `.lua` 文件用鼠标拖到 [一键翻译.cmd](一键翻译.cmd) 的图标上，松手即可：

- 可以**一次拖多个**文件，会挨个翻译；
- 结果自动生成在**被拖文件旁边的「翻译结果」文件夹**里，跑完会自动打开该文件夹；
- 文件名带中文或空格都没问题。

觉得每次找文件麻烦，可以右键 `一键翻译.cmd` → **发送到 → 桌面快捷方式**，
以后把 lua 文件拖到桌面那个快捷方式上就行。

窗口里显示 `[DONE]` 就是成功，`[FAILED]` 会带上中文报错原因。

## 用法二：命令行

需要 Node.js（本机已装 v26）。三种用法任选：

```powershell
# 1) 直接运行（结果放在输入文件旁的「翻译结果」文件夹）
node translate-classes.js "C:\路径\sgame3.lua"

# 2) 指定输出目录
node translate-classes.js "C:\路径\sgame3.lua" --out "D:\翻译结果"

# 3) 跑完自动打开输出目录
node translate-classes.js "C:\路径\sgame3.lua" --open
```

## 输出文件

默认输出目录 = 输入文件旁边的「翻译结果」文件夹（也可用 `--out` 指定）。里面有：

| 文件 | 用途 |
| --- | --- |
| `*_zh.lua` | **主输出**：名字后追加 `\n中文`，原文结构与偏移完全不变 |
| `*_annotated.lua` | 加 `--annotate` 才生成：原文件 + 行尾中文注释，不改任何字符串 |
| `class_names.csv` | 类名对照表（英文, 中文, 拆词），带 BOM，Excel 双击不乱码 |
| `field_names.csv` | 字段名对照表（所属类, 类型前缀, 原字段名, 中文） |
| `class_names.json` | 结构化映射，方便自己写脚本二次处理 |
| `class_names_zh.md` | 按类名前缀分组的阅读版，含每个类的字段 |
| `unknown-words.json` | 词典没覆盖的词；补完词典重跑即可 |

运行结束会自动做 Lua 语法校验，并检查是否有重复键：

```
✔ com.tencent.tmgp.sgame3_zh.lua  lua 表合法：7865 个表 / 21794 个字段，无重复键
```

还可以单独做往返校验，确认生成文件里 `\n` 前面就是源文件里的原名：

```powershell
node check-roundtrip.js "源文件.lua" "out\xxx_zh.lua"
# ✔ 往返校验通过：7864 个名字全部为「原名\n中文」，前半段与源文件逐字一致
```

## 改词典（提高/修正翻译质量）

词典是 [glossary.json](glossary.json)，四块：

```jsonc
{
  "words":     { "Buff": "增益", "b": "" },      // 普通词，大小写不敏感；值写 "" 表示丢弃该词
  "compounds": { "BianShen": "变身" },           // 复合词，优先于逐词拆分（解决歧义）
  "phrases":   { "整个类名": "整条中文" },       // 整条覆盖，最高优先级
  "keep":      [ "ADG", "UI", "AGE" ]            // 原样保留；区分大小写（AGE 框架 ≠ Age 推进）
}
```

工作流：跑一次 → 看 `unknown-words.json` → 把词和中文填进 `words` → 重跑，直到提示「词典完全覆盖」。

想只改几个词、不动内置词典，可以另存一份覆盖词典后用 `--glossary 我的词典.json`。

辅助工具：

```powershell
# 看某个类/关键词下面的字段，判断缩写含义
node inspect-class.js sgame3.lua Guishi Chibi Crik

# 看某个词出现在哪些字段里（补词典时最常用）
node find-word.js sgame3.lua vdspeeds Nuff Asix

# 只统计词频
node translate-classes.js sgame3.lua --words --sample 100
```

## 注意事项

- 默认是**追加**，原名和中文在同一个字符串里，英文名字仍然能搜到，不会丢信息。
- 如果你的代码里是把这个名字拿去和配置表做等值匹配的，那追加后就不再相等——这种情况用 `--annotate`（不改字符串）或 `--replace`（纯中文替换）。
- `Guishi`、`Project8` 这类项目代号默认保留原文；想翻译就在 `words` 里加一条（如 `"Guishi": "鬼事"`）。
- 类型前缀、`flags` 值、偏移数字永远不翻译。

## 在线工具能不能替代

不能直接替代：DeepL / 百度翻译 / 彩云小译 对整串标识符几乎无效。
它们的正确用法是配合本工具的 `class_names.csv`——把「中文翻译」列留空的行贴进去查缺补漏。
如果你只是想人工看，`class_names_zh.md` 比任何翻译网站都直观。
